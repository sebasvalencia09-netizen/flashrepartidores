# Flash Repartidores Web
1. Sube esta carpeta a Netlify en https://app.netlify.com/drop
2. Edita script.js si deseas conectar EmailJS con tu correo.
3. Personaliza textos en index.html según tu necesidad.
